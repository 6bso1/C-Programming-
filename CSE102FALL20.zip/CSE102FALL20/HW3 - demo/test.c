#include <stdio.h>
#include <string.h>

void find_location(char w[10]);

void main()
{
	FILE *fp1 = fopen("input1.txt", "r");

	char word[10];

	while(!feof(fp1))
	{
		fgets(word, 10, fp1);
		printf("%s\n", word);
		find_location(word, );
	}
	fclose(fp1);
}

void find_location(char w[10], char *file)
{
	FILE *fp2 = fopen("input2.txt", "r");
	FILE *fp3 = fopen("output.txt", "a");
	printf("%s\n", w);

	int i, j=0, k=0, length=1, temp;
	char matrix[100][250], ch;
	int len1 = strlen(w);

	while(!feof(fp2))
	{
		fgets(matrix[j], 250, fp2);
		j++;
	}
	fclose(fp2);

	for(i=0; i<j; i++)
	{
		int len2 = strlen(matrix[i]);
		for(k=0; k<len2; k++)
		{
			if(matrix[i][k] == w[0])
			{
				temp = k;
				for(int a=0; a<len1; a++)
				{
					if(matrix[i][k+a] == w[a])
					{
						length++;
					}
				}
			}
		}
		printf("%d %d\n", length, len1);
		if(length == strlen(w))
		{
			printf("jokes on you\n");
			fprintf(fp3, "%s (%d, %d) Horizontal\n", w, i, temp);
			break;
		}
		else
		{
			length = 1;
			k = 0;
			temp = 0;
		}
	}
}